<h1 align="center">
	<img src="https://i.imgur.com/4sWdkoB.png" alt="Mirai V2">
</h1>

<p align="center">
	<a href="https://github.com/ProCoderMew/Module-Miraiv2/commits" target="_blank"><img alt="commits" src="https://img.shields.io/github/commit-activity/m/ProCoderMew/Module-Miraiv2.svg?label=commit&style=flat-square"></a>
	<a href="https://github.com/ProCoderMew/Module-Miraiv2/issues" target="_blank"><img alt="GitHub issues" src="https://img.shields.io/github/issues/ProCoderMew/Module-Miraiv2"></a>
	<a href="https://github.com/ProCoderMew/Module-Miraiv2/stargazers" target="_blank"><img alt="GitHub stars" src="https://img.shields.io/github/stars/ProCoderMew/Module-Miraiv2"></a>
</p>

# Module hỗ trợ cho source [CatalizCS/Miraiv2](https://github.com/catalizcs/miraiv2)

# Các thay đổi

<details>

- 1/4/2021: Thêm module sim, img, slap, hitbutt.

- 21/4/2021: Update module img.

- 22/4/2021: Update module sim.

</details>

# Location
- Vị trí lưu module: [modules/commands](https://github.com/catalizcs/miraiv2/tree/main/modules/commands)

# Module
- **simsimi** - Chat cùng simsimi: [sim.js](modules/commands/sim.js)
- **image** - Kho Ảnh Trai, Gái, Cosplay: [img.js](modules/commands/img.js)
- **hitbutt** - Tét Mông người được tag: [hitbutt.js](modules/commands/hitbutt.js)
- **slap** - Tát toang alo người được tag: [slap.js](modules/commands/slap.js)

# Author
- **ProCoderMew** - [GitHub](https://github.com/ProCoderMew)

# License

- [LICENSE](LICENSE)
